@extends('layouts.layout')
@section('title')
Ошибка
@endsection
@section('content')
<div class="r404">
    <br>
    <h4 class="text-center">Кажется такая страница не найдена, вы можете вернуться на <a href="/">главную страницу</a></h4>
    <img class="" width="1000px" style="margin: auto;" src="/image/404.png" alt="">
</div>

@endsection


